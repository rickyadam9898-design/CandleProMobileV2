package com.candlepro.alarm

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.max

class CaptureService : Service() {
    companion object {
        const val ACTION_UPDATE = "com.candlepro.alarm.UPDATE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CHANNEL = "candlepro_capture"
        private const val NOTIFICATION_ID = 44
    }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var lastSignal = "WAIT"
    private var lastAlertAt = 0L

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, Notification.Builder(this, CHANNEL)
            .setContentTitle("CandlePro sedang membaca layar")
            .setContentText("Tekan STOP dari aplikasi untuk mengakhiri")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build())
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = getProjectionIntent(intent)
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        startCapture(code, data)
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun getProjectionIntent(intent: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent?.getParcelableExtra(EXTRA_DATA)

    private fun startCapture(code: Int, data: Intent) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        projection = (getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
            .getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(Looper.getMainLooper()))
        display = projection?.createVirtualDisplay("CandleProCapture", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
        reader?.setOnImageAvailableListener({ ir ->
            val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            try { analyze(image) } finally { image.close() }
        }, Handler(Looper.getMainLooper()))
    }

    private fun analyze(image: Image) {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val width = image.width
        val height = image.height
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val rowPadding = rowStride - pixelStride * width
        val paddedWidth = width + rowPadding / pixelStride
        val xStart = (width * 0.08).toInt()
        val xEnd = (width * 0.92).toInt()
        val yStart = (height * 0.12).toInt()
        val yEnd = (height * 0.76).toInt()
        val columns = mutableListOf<Pair<Int, Int>>()
        for (x in xStart until xEnd step 2) {
            var red = 0; var green = 0
            for (y in yStart until yEnd step 3) {
                val i = (y * paddedWidth + x) * pixelStride
                if (i + 2 >= bytes.size) continue
                val r = bytes[i].toInt() and 255
                val g = bytes[i + 1].toInt() and 255
                val b = bytes[i + 2].toInt() and 255
                if (r > 135 && r > g * 1.25 && r > b * 1.15) red++
                if (g > 105 && g > r * 1.18 && g > b * 1.08) green++
            }
            if (red + green >= 3) columns.add(red to green)
        }
        val bars = mutableListOf<String>()
        var r = 0; var g = 0
        for ((rr, gg) in columns) {
            if (rr + gg > 0) { r += rr; g += gg }
            else if (r + g > 0) { bars.add(if (g >= r) "UP" else "DOWN"); r = 0; g = 0 }
        }
        if (r + g > 0) bars.add(if (g >= r) "UP" else "DOWN")
        val recent = bars.takeLast(5)
        val signal = when {
            recent.size >= 3 && recent.takeLast(2).all { it == "UP" } && recent[recent.size-3] == "DOWN" -> "CALL"
            recent.size >= 3 && recent.takeLast(2).all { it == "DOWN" } && recent[recent.size-3] == "UP" -> "PUT"
            else -> "WAIT"
        }
        val detail = "Bar terdeteksi: ${bars.size} • Pola terakhir: ${recent.joinToString()} • Heuristik warna, belum validasi indikator."
        sendUpdate(signal, detail)
        val now = System.currentTimeMillis()
        if (signal != "WAIT" && signal != lastSignal && now - lastAlertAt > 8000) {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0,250,120,250), -1))
            else vibrator.vibrate(500)
            lastAlertAt = now
        }
        lastSignal = signal
    }

    private fun sendUpdate(signal: String, detail: String) {
        sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).putExtra("signal", signal).putExtra("detail", detail))
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    override fun onDestroy() {
        reader?.setOnImageAvailableListener(null, null)
        display?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
