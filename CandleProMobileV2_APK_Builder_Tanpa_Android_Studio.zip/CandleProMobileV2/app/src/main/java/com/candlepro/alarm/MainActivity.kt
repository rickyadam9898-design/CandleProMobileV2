package com.candlepro.alarm

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private val requestCapture = 7001
    private lateinit var status: TextView
    private lateinit var signal: TextView
    private lateinit var detail: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(17, 24, 39))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE): TextView =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER }
        root.addView(label("CANDLEPRO MOBILE V2", 23f))
        root.addView(label("BINOMO • SCREEN SIGNAL ALARM", 12f, Color.LTGRAY))
        status = label("STATUS: STOPPED", 14f, Color.YELLOW)
        root.addView(status)
        signal = label("WAIT", 42f, Color.YELLOW)
        root.addView(signal)
        detail = label("Izinkan screen capture, lalu buka chart Binomo.", 14f, Color.LTGRAY)
        root.addView(detail)
        val start = Button(this).apply {
            text = "MULAI BACA LAYAR"
            setOnClickListener {
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
            }
        }
        root.addView(start)
        root.addView(Button(this).apply {
            text = "STOP ALARM"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)); status.text = "STATUS: STOPPED"; signal.text = "WAIT" }
        })
        root.addView(label("Catatan: sinyal bersifat eksperimen, bukan jaminan profit. Uji di akun demo.", 12f, Color.LTGRAY))
        setContentView(root)

        registerReceiverCompat()
    }

    @Suppress("DEPRECATION")
    private fun registerReceiverCompat() {
        val filter = android.content.IntentFilter(CaptureService.ACTION_UPDATE)
        if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, filter)
    }

    private val receiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val s = intent?.getStringExtra("signal") ?: "WAIT"
            val why = intent?.getStringExtra("detail") ?: ""
            signal.text = s
            signal.setTextColor(when(s) { "CALL" -> Color.rgb(34,197,94); "PUT" -> Color.rgb(239,68,68); else -> Color.YELLOW })
            detail.text = why
            status.text = "STATUS: SCANNING"
        }
    }

    @Deprecated("Deprecated Android callback retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            status.text = "STATUS: SCANNING"
            detail.text = "Pembacaan layar berjalan. Pindah ke chart Binomo."
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
