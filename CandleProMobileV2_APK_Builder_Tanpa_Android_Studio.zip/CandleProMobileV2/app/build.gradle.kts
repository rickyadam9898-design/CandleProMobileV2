plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.candlepro.alarm"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.candlepro.alarm"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "2.0"
    }
}
