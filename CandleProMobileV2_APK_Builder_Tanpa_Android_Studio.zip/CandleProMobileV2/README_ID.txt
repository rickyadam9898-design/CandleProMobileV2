CANDLEPRO MOBILE V2 — PROJECT ANDROID

Isi:
- Pembacaan layar Android menggunakan MediaProjection (izin screen capture harus disetujui pengguna).
- Dashboard CALL / PUT / WAIT.
- Alarm getar saat sinyal heuristik berubah.
- Tidak ada transaksi otomatis.

CARA MEMBUKA:
1. Ekstrak ZIP ini.
2. Buka Android Studio.
3. Pilih Open, lalu pilih folder CandleProMobileV2.
4. Tunggu Gradle Sync. Gunakan Android Studio/JDK 17 dan Android SDK 35.
5. Hubungkan HP Android (USB debugging aktif) atau gunakan emulator.
6. Tekan Run untuk memasang aplikasi.

CARA PAKAI:
1. Buka CandlePro Alarm.
2. Tekan MULAI BACA LAYAR dan setujui izin berbagi/rekam layar.
3. Pindah ke aplikasi Binomo dan tampilkan chart.
4. Kembali ke CandlePro untuk melihat sinyal, atau biarkan service berjalan.
5. Tekan STOP ALARM untuk menghentikan.

BATASAN PENTING:
- Ini project sumber Android Studio, bukan APK siap install.
- Analisis saat ini adalah prototipe heuristik warna candle dari seluruh area chart; belum membaca data harga asli, belum menghitung RSI/EMA/Bollinger Bands yang akurat, dan dapat salah mendeteksi elemen UI.
- Warna/layout chart, tema, zoom, orientasi, dan perangkat memengaruhi hasil.
- Screen capture dapat menampilkan dialog sensitif; jangan merekam layar yang berisi kata sandi, OTP, atau data pribadi.
- Uji di akun demo. Sinyal bukan saran investasi dan tidak menjamin profit.
